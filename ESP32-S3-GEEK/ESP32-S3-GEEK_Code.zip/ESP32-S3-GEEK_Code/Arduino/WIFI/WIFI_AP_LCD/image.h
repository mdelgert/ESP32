#ifndef _IMAGE_H_
#define _IMAGE_H_
#include <pgmspace.h>
extern PROGMEM const unsigned char gImage_70X70[];
extern PROGMEM const unsigned char gImage_pic1[];

#endif
