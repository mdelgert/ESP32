ESP32

SPI:	
	CLK	12
	DIN	11	
	
	RST	3
	DC	46
	CS	10
	BLK           8